import Image from "next/image"
import Link from "next/link"
import { CalendarIcon } from "lucide-react"

import { Navbar } from "@/components/navbar"
import { Footer } from "@/components/footer"
import { Card, CardContent, CardDescription, CardFooter, CardHeader, CardTitle } from "@/components/ui/card"
import { Button } from "@/components/ui/button"
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs"

export default function NoticiasPage() {
  // Datos de ejemplo para las noticias
  const noticias = [
    {
      id: "temporada-2-inicio",
      title: "Comienza la Temporada 2 de Spanish GT League",
      date: "1 de Mayo, 2025",
      excerpt:
        "La segunda temporada de la Spanish GT League arranca este fin de semana con novedades en el formato y nuevos circuitos.",
      image: "/placeholder.svg?height=300&width=600",
      category: "anuncios",
    },
    {
      id: "nuevos-equipos",
      title: "Presentación de los equipos para la Temporada 2",
      date: "25 de Abril, 2025",
      excerpt:
        "Conoce a los 8 equipos titulares que competirán en la nueva temporada de la Spanish GT League con sus pilotos y coches.",
      image: "/placeholder.svg?height=300&width=600",
      category: "equipos",
    },
    {
      id: "calendario-oficial",
      title: "Calendario oficial de la Temporada 2",
      date: "20 de Abril, 2025",
      excerpt:
        "Publicamos el calendario oficial con las 12 carreras que compondrán la segunda temporada de nuestra liga.",
      image: "/placeholder.svg?height=300&width=600",
      category: "anuncios",
    },
    {
      id: "entrevista-campeon",
      title: "Entrevista con el campeón de la Temporada 1",
      date: "15 de Abril, 2025",
      excerpt: "Hablamos con el campeón de la temporada anterior sobre sus estrategias y expectativas para este año.",
      image: "/placeholder.svg?height=300&width=600",
      category: "entrevistas",
    },
    {
      id: "cambios-reglamento",
      title: "Cambios en el reglamento para la Temporada 2",
      date: "10 de Abril, 2025",
      excerpt:
        "Repasamos los cambios más importantes en el reglamento para la nueva temporada de la Spanish GT League.",
      image: "/placeholder.svg?height=300&width=600",
      category: "anuncios",
    },
    {
      id: "guia-circuitos",
      title: "Guía de circuitos de la Temporada 2",
      date: "5 de Abril, 2025",
      excerpt:
        "Analizamos los 12 circuitos que formarán parte del calendario de la segunda temporada con consejos y trucos.",
      image: "/placeholder.svg?height=300&width=600",
      category: "guias",
    },
  ]

  return (
    <div className="flex min-h-screen flex-col">
      <Navbar />
      <main className="flex-1">
        <div className="container mx-auto px-4 py-8">
          <div className="mb-8">
            <h1 className="text-3xl font-bold">Noticias</h1>
            <p className="mt-2 text-muted-foreground">
              Mantente al día con las últimas novedades de la Spanish GT League
            </p>
          </div>

          <Tabs defaultValue="todas" className="w-full">
            <TabsList className="grid w-full grid-cols-2 md:grid-cols-5">
              <TabsTrigger value="todas">Todas</TabsTrigger>
              <TabsTrigger value="anuncios">Anuncios</TabsTrigger>
              <TabsTrigger value="equipos">Equipos</TabsTrigger>
              <TabsTrigger value="entrevistas">Entrevistas</TabsTrigger>
              <TabsTrigger value="guias">Guías</TabsTrigger>
            </TabsList>

            <TabsContent value="todas" className="mt-6">
              <div className="grid gap-6 md:grid-cols-2 lg:grid-cols-3">
                {noticias.map((noticia) => (
                  <Card key={noticia.id} className="overflow-hidden">
                    <div className="relative h-[200px] w-full">
                      <Image
                        src={noticia.image || "/placeholder.svg"}
                        alt={noticia.title}
                        fill
                        className="object-cover"
                      />
                    </div>
                    <CardHeader>
                      <CardTitle className="line-clamp-2">{noticia.title}</CardTitle>
                      <CardDescription className="flex items-center gap-1">
                        <CalendarIcon className="h-4 w-4" />
                        {noticia.date}
                      </CardDescription>
                    </CardHeader>
                    <CardContent>
                      <p className="line-clamp-3">{noticia.excerpt}</p>
                    </CardContent>
                    <CardFooter>
                      <Button asChild>
                        <Link href={`/noticias/${noticia.id}`}>Leer más</Link>
                      </Button>
                    </CardFooter>
                  </Card>
                ))}
              </div>
            </TabsContent>

            {["anuncios", "equipos", "entrevistas", "guias"].map((category) => (
              <TabsContent key={category} value={category} className="mt-6">
                <div className="grid gap-6 md:grid-cols-2 lg:grid-cols-3">
                  {noticias
                    .filter((noticia) => noticia.category === category)
                    .map((noticia) => (
                      <Card key={noticia.id} className="overflow-hidden">
                        <div className="relative h-[200px] w-full">
                          <Image
                            src={noticia.image || "/placeholder.svg"}
                            alt={noticia.title}
                            fill
                            className="object-cover"
                          />
                        </div>
                        <CardHeader>
                          <CardTitle className="line-clamp-2">{noticia.title}</CardTitle>
                          <CardDescription className="flex items-center gap-1">
                            <CalendarIcon className="h-4 w-4" />
                            {noticia.date}
                          </CardDescription>
                        </CardHeader>
                        <CardContent>
                          <p className="line-clamp-3">{noticia.excerpt}</p>
                        </CardContent>
                        <CardFooter>
                          <Button asChild>
                            <Link href={`/noticias/${noticia.id}`}>Leer más</Link>
                          </Button>
                        </CardFooter>
                      </Card>
                    ))}
                </div>
              </TabsContent>
            ))}
          </Tabs>
        </div>
      </main>
      <Footer />
    </div>
  )
}
