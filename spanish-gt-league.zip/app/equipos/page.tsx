import { CarIcon, UsersIcon } from "lucide-react"

import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card"
import { Avatar, AvatarFallback, AvatarImage } from "@/components/ui/avatar"
import { Navbar } from "@/components/navbar"
import { Footer } from "@/components/footer"

export default function EquiposPage() {
  // Datos de los equipos oficiales
  const teams = [
    {
      id: "bmw-motorsport",
      name: "BMW MOTORSPORT",
      logo: "/placeholder.svg?height=100&width=100",
      car: "BMW M4 GT3",
      category: "GT3",
      drivers: [
        { name: "ger_47g", avatar: "/placeholder.svg?height=40&width=40" },
        { name: "Ako45🇨🇴", avatar: "/placeholder.svg?height=40&width=40" },
      ],
    },
    {
      id: "martini-porsche",
      name: "MARTINI PORSCHE",
      logo: "/placeholder.svg?height=100&width=100",
      car: "Porsche 911 GT3 R",
      category: "GT3",
      drivers: [{ name: "Lauda", avatar: "/placeholder.svg?height=40&width=40" }],
    },
    {
      id: "ferrari-peugeot",
      name: "FERRARI PEUGEOT",
      logo: "/placeholder.svg?height=100&width=100",
      car: "Ferrari 488 GT3",
      category: "GT3",
      drivers: [
        { name: "BUASPORTT", avatar: "/placeholder.svg?height=40&width=40" },
        { name: "KraclosSainz33", avatar: "/placeholder.svg?height=40&width=40" },
      ],
    },
    {
      id: "nissan-nismo",
      name: "NISSAN NISMO",
      logo: "/placeholder.svg?height=100&width=100",
      car: "Nissan GT-R Nismo GT3",
      category: "GT3",
      drivers: [
        { name: "[SGTL] megaplayer-200", avatar: "/placeholder.svg?height=40&width=40" },
        { name: "die27arm", avatar: "/placeholder.svg?height=40&width=40" },
      ],
    },
    {
      id: "lamborghini-shell-racing",
      name: "LAMBORGHINI SHELL RACING",
      logo: "/placeholder.svg?height=100&width=100",
      car: "Lamborghini Huracán GT3",
      category: "GT3",
      drivers: [
        { name: "VØZZA007🇻🇪", avatar: "/placeholder.svg?height=40&width=40" },
        { name: "León XIV", avatar: "/placeholder.svg?height=40&width=40" },
      ],
    },
    {
      id: "mercedes-amg",
      name: "MERCEDES AMG",
      logo: "/placeholder.svg?height=100&width=100",
      car: "Mercedes-AMG GT3",
      category: "GT3",
      drivers: [
        { name: "Jonopublox", avatar: "/placeholder.svg?height=40&width=40" },
        { name: "DanielXpro09", avatar: "/placeholder.svg?height=40&width=40" },
      ],
    },
    {
      id: "audi",
      name: "AUDI",
      logo: "/placeholder.svg?height=100&width=100",
      car: "Audi R8 LMS GT3",
      category: "GT3",
      drivers: [
        { name: "Moi", avatar: "/placeholder.svg?height=40&width=40" },
        { name: "R. Pleitez", avatar: "/placeholder.svg?height=40&width=40" },
      ],
    },
    {
      id: "dodge-potenza",
      name: "DODGE POTENZA",
      logo: "/placeholder.svg?height=100&width=100",
      car: "Dodge Viper GT3-R",
      category: "GT3",
      drivers: [
        { name: "Capri_29", avatar: "/placeholder.svg?height=40&width=40" },
        { name: "Juleen", avatar: "/placeholder.svg?height=40&width=40" },
      ],
    },
  ]

  // Equipos suplentes
  const reserveTeams = [
    {
      id: "ford-redur-racing-team",
      name: "FORD REDUR RACING TEAM",
      logo: "/placeholder.svg?height=100&width=100",
      car: "Ford GT",
      category: "GT3",
      drivers: [
        { name: "Erperezzzz(Izan)", avatar: "/placeholder.svg?height=40&width=40" },
        { name: "Juanmasp79", avatar: "/placeholder.svg?height=40&width=40" },
      ],
    },
    {
      id: "toyota",
      name: "TOYOTA",
      logo: "/placeholder.svg?height=100&width=100",
      car: "Toyota GR Supra GT3",
      category: "GT3",
      drivers: [
        { name: "Rivaldios", avatar: "/placeholder.svg?height=40&width=40" },
        { name: "Ringmeisters", avatar: "/placeholder.svg?height=40&width=40" },
      ],
    },
    {
      id: "mclaren",
      name: "MCLAREN",
      logo: "/placeholder.svg?height=100&width=100",
      car: "McLaren 720S GT3",
      category: "GT3",
      drivers: [
        { name: "Garrido_010", avatar: "/placeholder.svg?height=40&width=40" },
        { name: "ᴅᴀᴠɪᴅ", avatar: "/placeholder.svg?height=40&width=40" },
      ],
    },
  ]

  return (
    <div className="flex min-h-screen flex-col">
      <Navbar />
      <main className="flex-1">
        <div className="container mx-auto px-4 py-8">
          <div className="mb-8">
            <h1 className="text-3xl font-bold">Equipos y Pilotos</h1>
            <p className="mt-2 text-muted-foreground">
              Conoce a todos los equipos y pilotos que participan en la Temporada 2 de la Spanish GT League
            </p>
          </div>

          <h2 className="mb-6 text-2xl font-bold">Equipos Oficiales</h2>
          <div className="grid gap-6 md:grid-cols-2 lg:grid-cols-3 xl:grid-cols-4">
            {teams.map((team) => (
              <Card key={team.id} className="overflow-hidden">
                <CardHeader className="pb-2">
                  <div className="flex items-center justify-between">
                    <Avatar className="h-12 w-12">
                      <AvatarImage src={team.logo || "/placeholder.svg"} alt={team.name} />
                      <AvatarFallback>{team.name.charAt(0)}</AvatarFallback>
                    </Avatar>
                    <span className="rounded-full bg-yellow-100 px-3 py-1 text-xs font-medium text-yellow-800">
                      {team.category}
                    </span>
                  </div>
                  <CardTitle className="mt-3">{team.name}</CardTitle>
                </CardHeader>
                <CardContent>
                  <div className="mb-4 flex items-center gap-2">
                    <CarIcon className="h-4 w-4 text-red-600" />
                    <span className="text-sm">{team.car}</span>
                  </div>

                  <div>
                    <div className="mb-2 flex items-center gap-2">
                      <UsersIcon className="h-4 w-4 text-red-600" />
                      <span className="text-sm font-medium">Pilotos</span>
                    </div>
                    <div className="space-y-2">
                      {team.drivers.map((driver, index) => (
                        <div key={index} className="flex items-center gap-2 rounded-lg bg-muted p-2">
                          <Avatar className="h-6 w-6">
                            <AvatarImage src={driver.avatar || "/placeholder.svg"} alt={driver.name} />
                            <AvatarFallback>{driver.name.charAt(0)}</AvatarFallback>
                          </Avatar>
                          <span className="text-sm">{driver.name}</span>
                        </div>
                      ))}
                    </div>
                  </div>
                </CardContent>
              </Card>
            ))}
          </div>

          <h2 className="mb-6 mt-12 text-2xl font-bold">Equipos Suplentes</h2>
          <div className="grid gap-6 md:grid-cols-2 lg:grid-cols-3">
            {reserveTeams.map((team) => (
              <Card key={team.id} className="overflow-hidden border-dashed">
                <CardHeader className="pb-2">
                  <div className="flex items-center justify-between">
                    <Avatar className="h-12 w-12">
                      <AvatarImage src={team.logo || "/placeholder.svg"} alt={team.name} />
                      <AvatarFallback>{team.name.charAt(0)}</AvatarFallback>
                    </Avatar>
                    <span className="rounded-full bg-gray-100 px-3 py-1 text-xs font-medium text-gray-800">
                      Suplente
                    </span>
                  </div>
                  <CardTitle className="mt-3">{team.name}</CardTitle>
                </CardHeader>
                <CardContent>
                  <div className="mb-4 flex items-center gap-2">
                    <CarIcon className="h-4 w-4 text-red-600" />
                    <span className="text-sm">{team.car}</span>
                  </div>

                  <div>
                    <div className="mb-2 flex items-center gap-2">
                      <UsersIcon className="h-4 w-4 text-red-600" />
                      <span className="text-sm font-medium">Pilotos</span>
                    </div>
                    <div className="space-y-2">
                      {team.drivers.map((driver, index) => (
                        <div key={index} className="flex items-center gap-2 rounded-lg bg-muted p-2">
                          <Avatar className="h-6 w-6">
                            <AvatarImage src={driver.avatar || "/placeholder.svg"} alt={driver.name} />
                            <AvatarFallback>{driver.name.charAt(0)}</AvatarFallback>
                          </Avatar>
                          <span className="text-sm">{driver.name}</span>
                        </div>
                      ))}
                    </div>
                  </div>
                </CardContent>
              </Card>
            ))}
          </div>

          <div className="mt-12 rounded-lg bg-muted p-6">
            <h2 className="mb-4 text-2xl font-bold">Información de Equipos</h2>
            <div className="grid gap-6 md:grid-cols-2">
              <div>
                <h3 className="mb-2 text-lg font-medium">Reglas de Equipos</h3>
                <ul className="list-inside list-disc space-y-1 text-muted-foreground">
                  <li>Cada equipo puede tener un máximo de 2 pilotos titulares</li>
                  <li>Los equipos compiten por el campeonato de constructores</li>
                  <li>Se permite un cambio de piloto por temporada</li>
                  <li>Los equipos deben mantener la misma decoración durante toda la temporada</li>
                </ul>
              </div>
              <div>
                <h3 className="mb-2 text-lg font-medium">Equipos Suplentes</h3>
                <p className="text-muted-foreground">
                  Los equipos suplentes pueden entrar en competición si algún equipo titular abandona la competición o
                  no puede participar en alguna carrera específica. Tienen las mismas obligaciones y derechos que los
                  equipos titulares una vez activados.
                </p>
              </div>
            </div>
          </div>
        </div>
      </main>
      <Footer />
    </div>
  )
}
