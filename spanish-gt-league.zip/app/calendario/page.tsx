import Link from "next/link"
import Image from "next/image"
import { MapPinIcon, CarIcon, InfoIcon } from "lucide-react"

import { Button } from "@/components/ui/button"
import { Card, CardContent, CardFooter, CardHeader, CardTitle } from "@/components/ui/card"
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs"
import { Navbar } from "@/components/navbar"
import { Footer } from "@/components/footer"

export default function CalendarioPage() {
  // Datos del calendario oficial de la Temporada 2
  const races = [
    {
      id: "race-1",
      number: 1,
      name: "Gran Premio de Mount Panorama",
      circuit: "Mount Panorama",
      country: "Australia",
      flag: "🇦🇺",
      category: "GT3",
      status: "completada",
      image: "/placeholder.svg?height=200&width=400",
    },
    {
      id: "race-2",
      number: 2,
      name: "Gran Premio de Suzuka",
      circuit: "Suzuka",
      country: "Japón",
      flag: "🇯🇵",
      category: "LMP1",
      status: "completada",
      image: "/placeholder.svg?height=200&width=400",
    },
    {
      id: "race-3",
      number: 3,
      name: "Gran Premio de Lago Maggiore",
      circuit: "Lago Maggiore",
      country: "Italia",
      flag: "🇮🇹",
      category: "GT3",
      status: "completada",
      image: "/placeholder.svg?height=200&width=400",
    },
    {
      id: "race-4",
      number: 4,
      name: "Gran Premio de Nürburgring",
      circuit: "Nürburgring 24H",
      country: "Alemania",
      flag: "🇩🇪",
      category: "GT3",
      status: "completada",
      image: "/placeholder.svg?height=200&width=400",
    },
    {
      id: "race-5",
      number: 5,
      name: "Gran Premio de Le Mans",
      circuit: "Le Mans",
      country: "Francia",
      flag: "🇫🇷",
      category: "LMP1",
      status: "completada",
      image: "/placeholder.svg?height=200&width=400",
    },
    {
      id: "race-6",
      number: 6,
      name: "Gran Premio de Spa",
      circuit: "Spa Francorchamps",
      country: "Bélgica",
      flag: "🇧🇪",
      category: "GT3",
      status: "completada",
      image: "/placeholder.svg?height=200&width=400",
    },
    {
      id: "race-7",
      number: 7,
      name: "Gran Premio de Monza",
      circuit: "Monza",
      country: "Italia",
      flag: "🇮🇹",
      category: "GT3",
      status: "próxima",
      image: "/placeholder.svg?height=200&width=400",
    },
    {
      id: "race-8",
      number: 8,
      name: "Gran Premio de Tokyo",
      circuit: "Tokyo Expressway",
      country: "Japón",
      flag: "🇯🇵",
      category: "GT3",
      status: "próxima",
      image: "/placeholder.svg?height=200&width=400",
    },
    {
      id: "race-9",
      number: 9,
      name: "Gran Premio de Watkins Glen",
      circuit: "Watkins Glen",
      country: "Estados Unidos",
      flag: "🇺🇸",
      category: "LMP1",
      status: "próxima",
      image: "/placeholder.svg?height=200&width=400",
    },
    {
      id: "race-10",
      number: 10,
      name: "Gran Premio de Laguna Seca",
      circuit: "Laguna Seca",
      country: "Estados Unidos",
      flag: "🇺🇸",
      category: "GT3",
      status: "próxima",
      image: "/placeholder.svg?height=200&width=400",
    },
    {
      id: "race-11",
      number: 11,
      name: "Gran Premio de Daytona",
      circuit: "Daytona",
      country: "Estados Unidos",
      flag: "🇺🇸",
      category: "LMP1",
      status: "próxima",
      image: "/placeholder.svg?height=200&width=400",
    },
    {
      id: "race-12",
      number: 12,
      name: "Gran Premio de Interlagos",
      circuit: "Interlagos",
      country: "Brasil",
      flag: "🇧🇷",
      category: "LMP1",
      status: "próxima",
      image: "/placeholder.svg?height=200&width=400",
    },
  ]

  const proximasCarreras = races.filter((race) => race.status === "próxima")
  const carrerasCompletadas = races.filter((race) => race.status === "completada")

  return (
    <div className="flex min-h-screen flex-col">
      <Navbar />
      <main className="flex-1">
        <div className="container mx-auto px-4 py-8">
          <div className="mb-8">
            <h1 className="text-3xl font-bold">Calendario de Carreras</h1>
            <p className="mt-2 text-muted-foreground">
              Consulta todas las fechas de la Temporada 2 de la Spanish GT League
            </p>
          </div>

          <div className="mb-8 rounded-lg overflow-hidden border">
            <Image
              src="/images/calendario-temporada-2.png"
              alt="Calendario Temporada 2"
              width={1000}
              height={400}
              className="w-full object-contain"
            />
          </div>

          <Tabs defaultValue="proximas" className="w-full">
            <TabsList className="grid w-full grid-cols-2">
              <TabsTrigger value="proximas">Próximas Carreras</TabsTrigger>
              <TabsTrigger value="completadas">Carreras Completadas</TabsTrigger>
            </TabsList>
            <TabsContent value="proximas" className="mt-6">
              <div className="grid gap-6 md:grid-cols-2 lg:grid-cols-3">
                {proximasCarreras.map((race) => (
                  <Card key={race.id} className="overflow-hidden">
                    <div className="relative h-[150px] w-full">
                      <Image src={race.image || "/placeholder.svg"} alt={race.circuit} fill className="object-cover" />
                      <div className="absolute top-2 left-2 bg-black/70 text-white px-3 py-1 rounded-full text-sm font-medium">
                        {race.number}
                      </div>
                      <div className="absolute top-2 right-2 bg-black/70 text-white px-3 py-1 rounded-full text-sm font-medium">
                        {race.category}
                      </div>
                    </div>
                    <CardHeader>
                      <CardTitle className="flex items-center gap-2">
                        <span className="text-xl">{race.flag}</span> {race.name}
                      </CardTitle>
                    </CardHeader>
                    <CardContent className="grid gap-3">
                      <div className="flex items-center gap-2">
                        <MapPinIcon className="h-4 w-4 text-red-600" />
                        <span>{race.circuit}</span>
                      </div>
                      <div className="flex items-center gap-2">
                        <CarIcon className="h-4 w-4 text-red-600" />
                        <span>Categoría: {race.category}</span>
                      </div>
                    </CardContent>
                    <CardFooter>
                      <Button className="w-full" asChild>
                        <Link href={`/calendario/${race.id}`}>Más Información</Link>
                      </Button>
                    </CardFooter>
                  </Card>
                ))}
              </div>
            </TabsContent>
            <TabsContent value="completadas" className="mt-6">
              <div className="grid gap-6 md:grid-cols-2 lg:grid-cols-3">
                {carrerasCompletadas.map((race) => (
                  <Card key={race.id} className="overflow-hidden">
                    <div className="relative h-[150px] w-full">
                      <Image src={race.image || "/placeholder.svg"} alt={race.circuit} fill className="object-cover" />
                      <div className="absolute top-2 left-2 bg-black/70 text-white px-3 py-1 rounded-full text-sm font-medium">
                        {race.number}
                      </div>
                      <div className="absolute top-2 right-2 bg-black/70 text-white px-3 py-1 rounded-full text-sm font-medium">
                        {race.category}
                      </div>
                    </div>
                    <CardHeader>
                      <CardTitle className="flex items-center gap-2">
                        <span className="text-xl">{race.flag}</span> {race.name}
                      </CardTitle>
                    </CardHeader>
                    <CardContent className="grid gap-3">
                      <div className="flex items-center gap-2">
                        <MapPinIcon className="h-4 w-4 text-red-600" />
                        <span>{race.circuit}</span>
                      </div>
                      <div className="flex items-center gap-2">
                        <InfoIcon className="h-4 w-4 text-red-600" />
                        <span className="font-medium text-green-600">Completada</span>
                      </div>
                    </CardContent>
                    <CardFooter className="grid grid-cols-2 gap-4">
                      <Button variant="outline" asChild>
                        <Link href={`/calendario/${race.id}`}>Detalles</Link>
                      </Button>
                      <Button asChild>
                        <Link href={`/resultados/${race.id}`}>Resultados</Link>
                      </Button>
                    </CardFooter>
                  </Card>
                ))}
              </div>
            </TabsContent>
          </Tabs>

          <div className="mt-12 rounded-lg bg-muted p-6">
            <h2 className="mb-4 text-2xl font-bold">Información del Campeonato</h2>
            <div className="grid gap-6 md:grid-cols-2">
              <div>
                <h3 className="mb-2 text-lg font-medium">Categorías</h3>
                <div className="space-y-4">
                  <div className="rounded-lg bg-background p-4 border">
                    <h4 className="font-medium text-yellow-500">GT3</h4>
                    <p className="mt-1 text-sm text-muted-foreground">
                      Vehículos de Gran Turismo con especificaciones GT3. Balance de rendimiento para garantizar
                      competitividad.
                    </p>
                  </div>
                  <div className="rounded-lg bg-background p-4 border">
                    <h4 className="font-medium text-red-500">LMP1</h4>
                    <p className="mt-1 text-sm text-muted-foreground">
                      Prototipos de Le Mans de la categoría superior. Mayor potencia y aerodinámica avanzada.
                    </p>
                  </div>
                </div>
              </div>
              <div>
                <h3 className="mb-2 text-lg font-medium">Sistema de Puntuación</h3>
                <div className="grid grid-cols-2 gap-2 text-sm">
                  <div>1° lugar: 25 puntos</div>
                  <div>6° lugar: 8 puntos</div>
                  <div>2° lugar: 18 puntos</div>
                  <div>7° lugar: 6 puntos</div>
                  <div>3° lugar: 15 puntos</div>
                  <div>8° lugar: 4 puntos</div>
                  <div>4° lugar: 12 puntos</div>
                  <div>9° lugar: 2 puntos</div>
                  <div>5° lugar: 10 puntos</div>
                  <div>10° lugar: 1 punto</div>
                </div>
                <p className="mt-2 text-sm text-muted-foreground">Punto adicional por vuelta rápida en carrera</p>
              </div>
            </div>
          </div>
        </div>
      </main>
      <Footer />
    </div>
  )
}
