import Link from "next/link"
import Image from "next/image"
import { CalendarIcon, MapPinIcon } from "lucide-react"

import { Button } from "@/components/ui/button"
import { Card, CardContent, CardFooter, CardHeader, CardTitle } from "@/components/ui/card"
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs"
import { Avatar, AvatarFallback, AvatarImage } from "@/components/ui/avatar"
import { Navbar } from "@/components/navbar"
import { Footer } from "@/components/footer"

export default function ResultadosPage() {
  // En una aplicación real, estos datos vendrían de una API o base de datos
  const races = [
    {
      id: "race-11",
      name: "Gran Premio de Monza",
      circuit: "Autodromo Nazionale Monza",
      date: "8 de Mayo, 2025",
      image: "/placeholder.svg?height=200&width=400",
      winner: "Carlos Martínez",
    },
    {
      id: "race-10",
      name: "Gran Premio de Suzuka",
      circuit: "Suzuka Circuit",
      date: "1 de Mayo, 2025",
      image: "/placeholder.svg?height=200&width=400",
      winner: "Miguel Sánchez",
    },
    {
      id: "race-9",
      name: "Gran Premio de Interlagos",
      circuit: "Autódromo José Carlos Pace",
      date: "24 de Abril, 2025",
      image: "/placeholder.svg?height=200&width=400",
      winner: "Javier López",
    },
    {
      id: "race-8",
      name: "Gran Premio de Silverstone",
      circuit: "Silverstone Circuit",
      date: "17 de Abril, 2025",
      image: "/placeholder.svg?height=200&width=400",
      winner: "Carlos Martínez",
    },
    {
      id: "race-7",
      name: "Gran Premio de Le Mans",
      circuit: "Circuit de la Sarthe",
      date: "10 de Abril, 2025",
      image: "/placeholder.svg?height=200&width=400",
      winner: "Antonio García",
    },
    {
      id: "race-6",
      name: "Gran Premio de Red Bull Ring",
      circuit: "Red Bull Ring",
      date: "3 de Abril, 2025",
      image: "/placeholder.svg?height=200&width=400",
      winner: "David Rodríguez",
    },
  ]

  return (
    <div className="flex min-h-screen flex-col">
      <Navbar />
      <main className="flex-1">
        <div className="container mx-auto px-4 py-8">
          <div className="mb-8">
            <h1 className="text-3xl font-bold">Resultados</h1>
            <p className="mt-2 text-muted-foreground">Consulta los resultados de todas las carreras de la temporada</p>
          </div>

          <Tabs defaultValue="ultimas" className="w-full">
            <TabsList className="grid w-full grid-cols-2">
              <TabsTrigger value="ultimas">Últimas Carreras</TabsTrigger>
              <TabsTrigger value="todas">Todas las Carreras</TabsTrigger>
            </TabsList>
            <TabsContent value="ultimas" className="mt-6">
              <div className="grid gap-6 md:grid-cols-2 lg:grid-cols-3">
                {races.slice(0, 3).map((race) => (
                  <Card key={race.id} className="overflow-hidden">
                    <div className="relative h-[150px] w-full">
                      <Image src={race.image || "/placeholder.svg"} alt={race.circuit} fill className="object-cover" />
                    </div>
                    <CardHeader>
                      <CardTitle>{race.name}</CardTitle>
                    </CardHeader>
                    <CardContent className="grid gap-3">
                      <div className="flex items-center gap-2">
                        <MapPinIcon className="h-4 w-4 text-red-600" />
                        <span>{race.circuit}</span>
                      </div>
                      <div className="flex items-center gap-2">
                        <CalendarIcon className="h-4 w-4 text-red-600" />
                        <span>{race.date}</span>
                      </div>
                      <div className="mt-2">
                        <span className="text-sm text-muted-foreground">Ganador:</span>
                        <div className="mt-1 flex items-center gap-2">
                          <Avatar className="h-6 w-6">
                            <AvatarImage src="/placeholder.svg?height=40&width=40" alt={race.winner} />
                            <AvatarFallback>{race.winner.charAt(0)}</AvatarFallback>
                          </Avatar>
                          <span className="font-medium">{race.winner}</span>
                        </div>
                      </div>
                    </CardContent>
                    <CardFooter>
                      <Button className="w-full" asChild>
                        <Link href={`/resultados/${race.id}`}>Ver Resultados Completos</Link>
                      </Button>
                    </CardFooter>
                  </Card>
                ))}
              </div>
            </TabsContent>
            <TabsContent value="todas" className="mt-6">
              <div className="rounded-lg border">
                <div className="grid grid-cols-12 gap-2 border-b bg-muted p-4 text-sm font-medium">
                  <div className="col-span-4 sm:col-span-3">Carrera</div>
                  <div className="col-span-4 hidden sm:block">Circuito</div>
                  <div className="col-span-3 sm:col-span-2">Fecha</div>
                  <div className="col-span-5 sm:col-span-3">Ganador</div>
                </div>
                {races.map((race) => (
                  <div
                    key={race.id}
                    className="grid grid-cols-12 gap-2 border-b p-4 text-sm last:border-0 hover:bg-muted/50"
                  >
                    <div className="col-span-4 sm:col-span-3">
                      <Link href={`/resultados/${race.id}`} className="font-medium hover:underline">
                        {race.name}
                      </Link>
                    </div>
                    <div className="col-span-4 hidden truncate text-muted-foreground sm:block">{race.circuit}</div>
                    <div className="col-span-3 sm:col-span-2 text-muted-foreground">{race.date}</div>
                    <div className="col-span-5 sm:col-span-3">
                      <div className="flex items-center gap-2">
                        <Avatar className="h-6 w-6">
                          <AvatarImage src="/placeholder.svg?height=40&width=40" alt={race.winner} />
                          <AvatarFallback>{race.winner.charAt(0)}</AvatarFallback>
                        </Avatar>
                        <span>{race.winner}</span>
                      </div>
                    </div>
                  </div>
                ))}
              </div>
            </TabsContent>
          </Tabs>
        </div>
      </main>
      <Footer />
    </div>
  )
}
