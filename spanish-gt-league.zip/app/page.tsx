import Image from "next/image"
import Link from "next/link"
import { CalendarIcon, CarIcon, InfoIcon } from "lucide-react"

import { Button } from "@/components/ui/button"
import { Card, CardContent, CardDescription, CardFooter, CardHeader, CardTitle } from "@/components/ui/card"
import { Navbar } from "@/components/navbar"
import { Footer } from "@/components/footer"

export default function Home() {
  return (
    <div className="flex min-h-screen flex-col">
      <Navbar />
      <main className="flex-1">
        {/* Hero Section */}
        <section className="relative bg-black">
          <div className="absolute inset-0 z-0 opacity-30">
            <Image
              src="/placeholder.svg?height=600&width=1600"
              alt="Gran Turismo 7 racing"
              fill
              className="object-cover"
              priority
            />
          </div>
          <div className="relative z-10 flex flex-col items-center justify-center px-4 py-24 text-center text-white md:py-32">
            <div className="mb-6 w-48 md:w-64">
              <Image
                src="/images/spanish-gt-league-logo.webp"
                alt="Spanish GT League Logo"
                width={300}
                height={300}
                className="w-full"
                priority
              />
            </div>
            <h1 className="mb-4 text-4xl font-extrabold tracking-tight md:text-5xl lg:text-6xl sr-only">
              Spanish GT League
            </h1>
            <p className="mb-8 max-w-3xl text-lg md:text-xl">
              La plataforma oficial de nuestra liga de Gran Turismo 7. Simracing competitivo en español, todo en un solo
              lugar.
            </p>
            <div className="flex flex-wrap justify-center gap-4">
              <Button size="lg" className="bg-red-600 hover:bg-red-700 text-white" asChild>
                <Link href="/calendario">Ver Calendario</Link>
              </Button>
              <Button
                size="lg"
                variant="outline"
                className="border-yellow-500 text-yellow-500 hover:bg-yellow-500 hover:text-black"
                asChild
              >
                <Link href="/reglamento">Reglamento</Link>
              </Button>
            </div>
          </div>
        </section>

        {/* Features Section */}
        <section className="container mx-auto px-4 py-16 bg-gradient-to-b from-black to-gray-900">
          <h2 className="mb-12 text-center text-3xl font-bold text-white">Todo lo que necesitas para competir</h2>
          <div className="grid gap-8 md:grid-cols-3 max-w-5xl mx-auto">
            <Card className="bg-black border-red-600 text-white">
              <CardHeader className="flex flex-row items-center gap-4 pb-2">
                <div className="h-12 w-12 rounded-full bg-red-600 flex items-center justify-center">
                  <CalendarIcon className="h-6 w-6 text-white" />
                </div>
                <div>
                  <CardTitle>Calendario</CardTitle>
                  <CardDescription className="text-gray-400">Fechas y horarios de todas las carreras</CardDescription>
                </div>
              </CardHeader>
              <CardContent>
                <p className="text-gray-300">
                  Mantente al día con nuestro calendario de eventos, incluyendo prácticas, clasificaciones y carreras.
                </p>
              </CardContent>
              <CardFooter>
                <Button
                  variant="outline"
                  className="w-full border-red-600 text-red-600 hover:bg-red-600 hover:text-white"
                  asChild
                >
                  <Link href="/calendario">Ver Calendario</Link>
                </Button>
              </CardFooter>
            </Card>
            <Card className="bg-black border-red-600 text-white">
              <CardHeader className="flex flex-row items-center gap-4 pb-2">
                <div className="h-12 w-12 rounded-full bg-red-600 flex items-center justify-center">
                  <CarIcon className="h-6 w-6 text-white" />
                </div>
                <div>
                  <CardTitle>Equipos</CardTitle>
                  <CardDescription className="text-gray-400">
                    Información sobre los equipos y sus coches
                  </CardDescription>
                </div>
              </CardHeader>
              <CardContent>
                <p className="text-gray-300">
                  Conoce a todos los equipos que participan en nuestra liga, sus pilotos y vehículos.
                </p>
              </CardContent>
              <CardFooter>
                <Button
                  variant="outline"
                  className="w-full border-red-600 text-red-600 hover:bg-red-600 hover:text-white"
                  asChild
                >
                  <Link href="/equipos">Ver Equipos</Link>
                </Button>
              </CardFooter>
            </Card>
            <Card className="bg-black border-yellow-500 text-white">
              <CardHeader className="flex flex-row items-center gap-4 pb-2">
                <div className="h-12 w-12 rounded-full bg-yellow-500 flex items-center justify-center">
                  <InfoIcon className="h-6 w-6 text-black" />
                </div>
                <div>
                  <CardTitle>Reglamento</CardTitle>
                  <CardDescription className="text-gray-400">Normas y procedimientos</CardDescription>
                </div>
              </CardHeader>
              <CardContent>
                <p className="text-gray-300">
                  Consulta el reglamento completo de la competición, penalizaciones y procedimientos.
                </p>
              </CardContent>
              <CardFooter>
                <Button
                  variant="outline"
                  className="w-full border-yellow-500 text-yellow-500 hover:bg-yellow-500 hover:text-black"
                  asChild
                >
                  <Link href="/reglamento">Ver Reglamento</Link>
                </Button>
              </CardFooter>
            </Card>
          </div>
        </section>

        {/* Calendario Section */}
        <section className="container mx-auto px-4 py-16 bg-gradient-to-b from-gray-900 to-black">
          <div className="text-center">
            <h2 className="text-3xl font-bold mb-8 text-white">Calendario Oficial Temporada 2</h2>
            <div className="rounded-lg overflow-hidden border border-red-600 max-w-4xl mx-auto">
              <Image
                src="/images/calendario-temporada-2.png"
                alt="Calendario Temporada 2"
                width={1000}
                height={400}
                className="w-full object-contain"
              />
            </div>
            <Button className="mt-8 bg-red-600 hover:bg-red-700 text-white" size="lg" asChild>
              <Link href="/calendario">Ver Calendario Completo</Link>
            </Button>
          </div>
        </section>
      </main>
      <Footer />
    </div>
  )
}
