import { Navbar } from "@/components/navbar"
import { Footer } from "@/components/footer"
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs"
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card"
import { Badge } from "@/components/ui/badge"

export default function ReglamentoPage() {
  return (
    <div className="flex min-h-screen flex-col">
      <Navbar />
      <main className="flex-1">
        <div className="container mx-auto px-4 py-8">
          <div className="mb-8">
            <h1 className="text-3xl font-bold">Reglamento Oficial</h1>
            <p className="mt-2 text-muted-foreground">Normativa completa de la Spanish GT League para la Temporada 2</p>
          </div>

          <Tabs defaultValue="coches" className="w-full">
            <TabsList className="grid w-full grid-cols-2 md:grid-cols-5">
              <TabsTrigger value="coches">Coches y Equipos</TabsTrigger>
              <TabsTrigger value="calendario">Calendario</TabsTrigger>
              <TabsTrigger value="sanciones">Sanciones</TabsTrigger>
              <TabsTrigger value="reservas">Reservas</TabsTrigger>
              <TabsTrigger value="horario">Horario</TabsTrigger>
            </TabsList>

            {/* COCHES Y EQUIPOS */}
            <TabsContent value="coches" className="mt-6">
              <Card>
                <CardHeader className="bg-gradient-to-r from-red-600 to-yellow-500 text-white">
                  <CardTitle className="text-2xl">1. COCHES Y EQUIPOS</CardTitle>
                </CardHeader>
                <CardContent className="pt-6">
                  <ul className="space-y-4">
                    <li className="flex items-start gap-2">
                      <span className="mt-1 flex h-6 w-6 shrink-0 items-center justify-center rounded-full bg-red-600 text-xs font-medium text-white">
                        1
                      </span>
                      <div>
                        <p className="font-medium">Solo pueden haber 8 equipos titulares</p>
                      </div>
                    </li>
                    <li className="flex items-start gap-2">
                      <span className="mt-1 flex h-6 w-6 shrink-0 items-center justify-center rounded-full bg-red-600 text-xs font-medium text-white">
                        2
                      </span>
                      <div>
                        <p className="font-medium">Cada equipo debe de tener un nombre</p>
                        <p className="text-green-600">
                          Obligatorio para identificación en clasificaciones y resultados
                        </p>
                      </div>
                    </li>
                    <li className="flex items-start gap-2">
                      <span className="mt-1 flex h-6 w-6 shrink-0 items-center justify-center rounded-full bg-red-600 text-xs font-medium text-white">
                        3
                      </span>
                      <div>
                        <p className="font-medium">
                          Los coches deben de incluir al menos 1 pegatina del logo de la Liga
                        </p>
                      </div>
                    </li>
                    <li className="flex items-start gap-2">
                      <span className="mt-1 flex h-6 w-6 shrink-0 items-center justify-center rounded-full bg-red-600 text-xs font-medium text-white">
                        4
                      </span>
                      <div>
                        <p className="font-medium">Cada piloto debe de llevar su número en ambos coches</p>
                      </div>
                    </li>
                    <li className="flex items-start gap-2">
                      <span className="mt-1 flex h-6 w-6 shrink-0 items-center justify-center rounded-full bg-red-600 text-xs font-medium text-white">
                        5
                      </span>
                      <div>
                        <p className="font-medium">Los coches de cada equipo deben de llevar la misma livery</p>
                      </div>
                    </li>
                    <li className="flex items-start gap-2">
                      <span className="mt-1 flex h-6 w-6 shrink-0 items-center justify-center rounded-full bg-red-600 text-xs font-medium text-white">
                        6
                      </span>
                      <div>
                        <p className="font-medium">Cada equipo debe de elegir un coche GT3 y un LMP1</p>
                      </div>
                    </li>
                    <li className="flex items-start gap-2">
                      <span className="mt-1 flex h-6 w-6 shrink-0 items-center justify-center rounded-full bg-red-600 text-xs font-medium text-white">
                        7
                      </span>
                      <div>
                        <p className="font-medium">Los coches solo se pueden usar del Brand Central</p>
                        <p className="text-green-600">Es decir, no se pueden usar coches históricos ni VGT</p>
                      </div>
                    </li>
                    <li className="flex items-start gap-2">
                      <span className="mt-1 flex h-6 w-6 shrink-0 items-center justify-center rounded-full bg-red-600 text-xs font-medium text-white">
                        8
                      </span>
                      <div>
                        <p className="font-medium">GT3: Una marca por equipo</p>
                      </div>
                    </li>
                    <li className="flex items-start gap-2">
                      <span className="mt-1 flex h-6 w-6 shrink-0 items-center justify-center rounded-full bg-red-600 text-xs font-medium text-white">
                        9
                      </span>
                      <div>
                        <p className="font-medium">
                          Antes de que empiece la temporada se deberán de presentar los diseños de ambos coches en el
                          canal de #diseños
                        </p>
                        <p className="text-green-600">Para revisión y aprobación por los organizadores</p>
                      </div>
                    </li>
                    <li className="flex items-start gap-2">
                      <span className="mt-1 flex h-6 w-6 shrink-0 items-center justify-center rounded-full bg-red-600 text-xs font-medium text-white">
                        10
                      </span>
                      <div>
                        <p className="font-medium">
                          Los diseños se deberán de publicar en el GT7 para que sean accedibles para todo el mundo (que
                          se pueden editar)
                        </p>
                      </div>
                    </li>
                  </ul>
                </CardContent>
              </Card>
            </TabsContent>

            {/* CALENDARIO/CARRERA */}
            <TabsContent value="calendario" className="mt-6">
              <Card>
                <CardHeader className="bg-gradient-to-r from-red-600 to-yellow-500 text-white">
                  <CardTitle className="text-2xl">2. CALENDARIO/CARRERA</CardTitle>
                </CardHeader>
                <CardContent className="pt-6">
                  <ul className="space-y-4">
                    <li className="flex items-start gap-2">
                      <span className="mt-1 flex h-6 w-6 shrink-0 items-center justify-center rounded-full bg-red-600 text-xs font-medium text-white">
                        1
                      </span>
                      <div>
                        <p className="font-medium">12 Carreras</p>
                        <p className="text-green-600">Temporada completa con variedad de circuitos</p>
                      </div>
                    </li>
                    <li className="flex items-start gap-2">
                      <span className="mt-1 flex h-6 w-6 shrink-0 items-center justify-center rounded-full bg-red-600 text-xs font-medium text-white">
                        2
                      </span>
                      <div>
                        <p className="font-medium">7 con los GT3</p>
                      </div>
                    </li>
                    <li className="flex items-start gap-2">
                      <span className="mt-1 flex h-6 w-6 shrink-0 items-center justify-center rounded-full bg-red-600 text-xs font-medium text-white">
                        3
                      </span>
                      <div>
                        <p className="font-medium">5 con los Lmp1 (No son multicategoría)</p>
                        <p className="text-green-600">Cada carrera es exclusiva de una categoría</p>
                      </div>
                    </li>
                    <li className="flex items-start gap-2">
                      <span className="mt-1 flex h-6 w-6 shrink-0 items-center justify-center rounded-full bg-red-600 text-xs font-medium text-white">
                        4
                      </span>
                      <div>
                        <p className="font-medium">Duración de las carreras: 1h</p>
                      </div>
                    </li>
                    <li className="flex items-start gap-2">
                      <span className="mt-1 flex h-6 w-6 shrink-0 items-center justify-center rounded-full bg-red-600 text-xs font-medium text-white">
                        5
                      </span>
                      <div>
                        <p className="font-medium">Duración de las qualys: 15min</p>
                      </div>
                    </li>
                    <li className="flex items-start gap-2">
                      <span className="mt-1 flex h-6 w-6 shrink-0 items-center justify-center rounded-full bg-red-600 text-xs font-medium text-white">
                        6
                      </span>
                      <div>
                        <p className="font-medium">Número de pilotos mínimo para hacer la carrera: 10 pilotos</p>
                      </div>
                    </li>
                    <li className="flex items-start gap-2">
                      <span className="mt-1 flex h-6 w-6 shrink-0 items-center justify-center rounded-full bg-red-600 text-xs font-medium text-white">
                        7
                      </span>
                      <div>
                        <p className="font-medium">
                          No se pueden cambiar ni las carreras ni los horarios ya empezada la temporada
                        </p>
                      </div>
                    </li>
                  </ul>
                </CardContent>
              </Card>
            </TabsContent>

            {/* SANCIONES */}
            <TabsContent value="sanciones" className="mt-6">
              <Card>
                <CardHeader className="bg-gradient-to-r from-red-600 to-yellow-500 text-white">
                  <CardTitle className="text-2xl">3. SANCIONES</CardTitle>
                </CardHeader>
                <CardContent className="pt-6">
                  <div className="mb-6 grid gap-4 md:grid-cols-3">
                    <div className="rounded-lg border bg-card p-4 shadow-sm">
                      <h3 className="mb-2 font-semibold">Contacto leve</h3>
                      <Badge variant="outline" className="bg-yellow-100 text-yellow-800">
                        5 segundos
                      </Badge>
                    </div>
                    <div className="rounded-lg border bg-card p-4 shadow-sm">
                      <h3 className="mb-2 font-semibold">Contacto grave</h3>
                      <Badge variant="outline" className="bg-orange-100 text-orange-800">
                        10 segundos
                      </Badge>
                    </div>
                    <div className="rounded-lg border bg-card p-4 shadow-sm">
                      <h3 className="mb-2 font-semibold">Contacto muy grave</h3>
                      <Badge variant="outline" className="bg-red-100 text-red-800">
                        20 segundos
                      </Badge>
                    </div>
                  </div>

                  <ul className="space-y-4">
                    <li className="flex items-start gap-2">
                      <span className="mt-1 flex h-6 w-6 shrink-0 items-center justify-center rounded-full bg-red-600 text-xs font-medium text-white">
                        1
                      </span>
                      <div>
                        <p className="font-medium">Superlicencia: 11pts</p>
                      </div>
                    </li>
                    <li className="flex items-start gap-2">
                      <span className="mt-1 flex h-6 w-6 shrink-0 items-center justify-center rounded-full bg-red-600 text-xs font-medium text-white">
                        2
                      </span>
                      <div>
                        <p className="font-medium">Acumulación de 20s = -3pts de superlicencia</p>
                        <p className="text-green-600">Se restan puntos por acumulación de penalizaciones</p>
                      </div>
                    </li>
                    <li className="flex items-start gap-2">
                      <span className="mt-1 flex h-6 w-6 shrink-0 items-center justify-center rounded-full bg-red-600 text-xs font-medium text-white">
                        3
                      </span>
                      <div>
                        <p className="font-medium">0pts de Superlicencia = RB (Race Ban)</p>
                        <p className="text-green-600">Prohibición de participar en la siguiente carrera</p>
                      </div>
                    </li>
                    <li className="flex items-start gap-2">
                      <span className="mt-1 flex h-6 w-6 shrink-0 items-center justify-center rounded-full bg-red-600 text-xs font-medium text-white">
                        4
                      </span>
                      <div>
                        <p className="font-medium">Molestar en Qualy = QB (Qualy Ban)</p>
                        <p className="text-green-600">Prohibición de participar en la siguiente clasificación</p>
                      </div>
                    </li>
                    <li className="flex items-start gap-2">
                      <span className="mt-1 flex h-6 w-6 shrink-0 items-center justify-center rounded-full bg-red-600 text-xs font-medium text-white">
                        5
                      </span>
                      <div>
                        <p className="font-medium">Acoso o ataques hacia otro piloto = RB (Race Ban)</p>
                      </div>
                    </li>
                    <li className="flex items-start gap-2">
                      <span className="mt-1 flex h-6 w-6 shrink-0 items-center justify-center rounded-full bg-red-600 text-xs font-medium text-white">
                        6
                      </span>
                      <div>
                        <p className="font-medium">Al final de cada carrera se podrá pedir sanción en #ticket</p>
                      </div>
                    </li>
                  </ul>
                </CardContent>
              </Card>
            </TabsContent>

            {/* RESERVAS */}
            <TabsContent value="reservas" className="mt-6">
              <Card>
                <CardHeader className="bg-gradient-to-r from-red-600 to-yellow-500 text-white">
                  <CardTitle className="text-2xl">4. RESERVAS</CardTitle>
                </CardHeader>
                <CardContent className="pt-6">
                  <ul className="space-y-4">
                    <li className="flex items-start gap-2">
                      <span className="mt-1 flex h-6 w-6 shrink-0 items-center justify-center rounded-full bg-red-600 text-xs font-medium text-white">
                        1
                      </span>
                      <div>
                        <p className="font-medium">A los reservas se les asignará el coche antes de la carrera</p>
                      </div>
                    </li>
                    <li className="flex items-start gap-2">
                      <span className="mt-1 flex h-6 w-6 shrink-0 items-center justify-center rounded-full bg-red-600 text-xs font-medium text-white">
                        2
                      </span>
                      <div>
                        <p className="font-medium">
                          Deberán de poner la livery del equipo en el que correrán en esa carrera
                        </p>
                        <p className="text-green-600">Para mantener la identidad visual del equipo</p>
                      </div>
                    </li>
                    <li className="flex items-start gap-2">
                      <span className="mt-1 flex h-6 w-6 shrink-0 items-center justify-center rounded-full bg-red-600 text-xs font-medium text-white">
                        3
                      </span>
                      <div>
                        <p className="font-medium">
                          Un reserva puede pasar a ser titular a un equipo si el piloto titular participa poco o no
                          participa.
                        </p>
                      </div>
                    </li>
                  </ul>
                </CardContent>
              </Card>
            </TabsContent>

            {/* HORARIO */}
            <TabsContent value="horario" className="mt-6">
              <Card>
                <CardHeader className="bg-gradient-to-r from-red-600 to-yellow-500 text-white">
                  <CardTitle className="text-2xl">5. HORARIO</CardTitle>
                </CardHeader>
                <CardContent className="pt-6">
                  <div className="flex flex-col items-center justify-center p-8 text-center">
                    <div className="mb-4 rounded-full bg-red-600 p-6">
                      <svg
                        xmlns="http://www.w3.org/2000/svg"
                        width="24"
                        height="24"
                        viewBox="0 0 24 24"
                        fill="none"
                        stroke="currentColor"
                        strokeWidth="2"
                        strokeLinecap="round"
                        strokeLinejoin="round"
                        className="h-10 w-10 text-white"
                      >
                        <circle cx="12" cy="12" r="10" />
                        <polyline points="12 6 12 12 16 14" />
                      </svg>
                    </div>
                    <h3 className="text-2xl font-bold">Sábados a las 19h hora española</h3>
                    <p className="mt-2 text-muted-foreground">
                      Las sesiones de clasificación comenzarán puntualmente, asegúrate de estar conectado con antelación
                    </p>
                  </div>
                </CardContent>
              </Card>
            </TabsContent>
          </Tabs>
        </div>
      </main>
      <Footer />
    </div>
  )
}
